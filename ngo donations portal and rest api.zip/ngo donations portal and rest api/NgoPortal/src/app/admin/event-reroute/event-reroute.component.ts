import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-event-reroute',
  templateUrl: './event-reroute.component.html',
  styleUrl: './event-reroute.component.css'
})
export class EventRerouteComponent {

  constructor(public router:Router){ 
    
  }

  async ngOnInit(){
    setTimeout(() =>{this.reload();}, 2000);
    
  }
  reload(){
    this.router.navigate(['/dashboard/events']);
  }
}
