import { Injectable } from '@angular/core';
import { DonationType } from '../model/donation-type';
import { HttpClient } from '@angular/common/http';
import { DonationCart } from '../model/donation-cart';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  eventList:any;
  event1!:DonationType|any;

  cart!:DonationCart [];
  
  constructor(private http:HttpClient) {
   }

  getAllEvents() {
    return this.http.get("http://localhost:8080/api/event/getAllEvents");
  }

  postEvent() {
    return this.http.post("http://localhost:8080/api/event/register", this.event1);
  }
  
  updateEvent(){
    return this.http.put("http://localhost:8080/api/event/updateEvent/"+this.event1.id, this.event1);
  }
  deleteEvent(id:number){
    if(window.confirm("Delete this event? This cannot be undone!")){
      let url = "http://localhost:8080/api/event/deleteEvent/" + id;
      return this.http.delete(url);
    }
    return null;
  }

}
