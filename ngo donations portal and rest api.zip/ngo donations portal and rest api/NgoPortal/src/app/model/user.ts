export class User {
    constructor(){}
    userId?: number | null | undefined;
    firstName?: string | null | undefined;
    lastName?: string | null | undefined;
    email?: string | null | undefined;
    password?: string | null | undefined;
    role?: string | null | undefined;
  }