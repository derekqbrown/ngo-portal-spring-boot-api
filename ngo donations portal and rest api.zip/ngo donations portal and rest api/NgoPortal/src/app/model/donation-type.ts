export class DonationType {
    constructor(){}
    id?: number | null | undefined;
    title?: string | null | undefined;
    description?: string | null | undefined;
    active?: boolean | null | undefined;
  }