import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { User } from '../model/user';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  userList:any;
  user!:User|any;
  tempUser!:User|any;
  loggedIn!: boolean;
  
  constructor(private http:HttpClient, private router:Router) { }

  getAllUsers() {
    return this.http.get("http://localhost:8080/api/user/getAllUsers");
  }

  login(user:User){
    this.user = user;
    return this.http.post("http://localhost:8080/api/user/login", this.user);
  
  }
  postUser() {
    return this.http.post("http://localhost:8080/api/user/register", this.tempUser);
  }
  
  updateUser(){
    return this.http.put("http://localhost:8080/api/user/updateUser/"+this.tempUser.userId, this.tempUser);
  }
  deleteUser(id:number){
    if(window.confirm("Delete your account? This cannot be undone!")){
      let url = "http://localhost:8080/api/user/deleteUser/" + id;
      return this.http.delete(url);
    }
    return null;
  }


  logout(){
    localStorage.clear();
    this.router.navigate(["/home"]);
    this.loggedIn = false;
    location.reload();
  }
}
