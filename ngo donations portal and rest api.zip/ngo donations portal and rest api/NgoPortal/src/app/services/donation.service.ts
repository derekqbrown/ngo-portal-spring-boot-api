import { Injectable } from '@angular/core';
import { Donation } from '../model/donation';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DonationService {
  donation!:Donation;
  donationList!:any;
  constructor(private http:HttpClient) {  }

  getAllDonations(){
    return this.http.get("http://localhost:8080/api/donation/donations");
  }
  postDonation() {
    return this.http.post("http://localhost:8080/api/donation/register", this.donation);
  }
}
