package ngoproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class NgoProjectMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(NgoProjectMain.class, args);
		
	}

}
